<div class="sidebar_main">
    <div class="sidebar_items">
        <div class="sidebar_logo">
            <a href="/"><img src="<?php echo e(asset('backend/assets/img/side_logo.png')); ?>"></a>
        </div>
        <div class="side_bar_nav">
            <ul class="side_menu list-unstyled">    
                <li class="active"><a href="javascript:;" ><img src="<?php echo e(asset('backend/assets/img/square.png')); ?>" alt=""><span>Lorem Ipsum</span></a></li>
                <li><a href="javascript:;" ><img src="<?php echo e(asset('backend/assets/img/tag.png')); ?>" alt=""><span>Lorem Ipsum</span></a></li>
                <li><a href="javascript:;" ><img src="<?php echo e(asset('backend/assets/img/house.png')); ?>" alt=""><span>Lorem Ipsum</span></a></li>
                <li><a href="javascript:;" ><img src="<?php echo e(asset('backend/assets/img/stat.png')); ?>" alt=""><span>Lorem Ipsum</span></a></li>
                <li><a href="javascript:;" ><img src="<?php echo e(asset('backend/assets/img/file.png')); ?>" alt=""><span>Lorem Ipsum</span></a></li>
                <li><a href="javascript:;" ><img src="<?php echo e(asset('backend/assets/img/setting.png')); ?>" alt=""><span>Lorem Ipsum</span></a></li>
                <li><a href="javascript:;" ><img src="<?php echo e(asset('backend/assets/img/mark.png')); ?>" alt=""><span>Lorem Ipsum</span></a></li>
            </ul>
        </div>
    </div>
    <div class="logout_btn">
        <a href="javascript:;"><i class="fa-solid fa-power-off"></i></a>
    </div>
</div><?php /**PATH C:\wamp64\www\prompt-xchange\resources\views\backend\partials\sidebar.blade.php ENDPATH**/ ?>