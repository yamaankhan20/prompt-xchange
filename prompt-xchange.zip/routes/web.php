<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\front\FrontController;
use App\Http\Controllers\backend\BackendController;
use App\Http\Controllers\Modelslab\ImagegeneratorController;
use Illuminate\Support\Facades\Auth;

// Route::get('/', function () {return view('home');});
Route::get('/', [FrontController::class, 'home'])->name('prompt.home');
Route::get('/about-us',[FrontController::class,'about'])->name('prompt.about');
Route::get('/contact-us',[FrontController::class,'contactus'])->name('prompt.contact');
Route::get('/pricing',[FrontController::class,'pricing'])->name('prompt.pricing');
Route::get('/blogs',[FrontController::class,'blogs'])->name('prompt.blogs');;
Route::get('/blog-details',[FrontController::class,'blogs_details'])->name('prompt.blogs_details');;



Route::get('/discover',[FrontController::class,'discover'])->name('prompt.explore');
Route::get('/hire',[FrontController::class,'hire'])->name('prompt.hire');
Route::get('/profile',[FrontController::class,'profile'])->name('prompt.profile');


Route::group(['middleware' => ['auth', 'role:Admin']], function () {
    Route::get('/dashboard',[BackendController::class,'dashboard'])->name('dashboard');
    Route::get('/create',[FrontController::class,'create'])->name('prompt.create');;
});


Route::group(['middleware' => ['auth', 'role:General User']], function () {
    Route::get('/dashboard',[BackendController::class,'dashboard'])->name('dashboard');
    Route::get('/create',[FrontController::class,'create'])->name('prompt.create');;
});

// Route::get('/test-role', function () {
//     $user = Auth::user();
//     dd($user->hasRole('General User')); // Should return true or false
// });
// Backend Routes

Route::post('/test-api',[BackendController::class,'testApi'])->name('generate.image');
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
