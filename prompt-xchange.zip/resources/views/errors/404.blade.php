@extends('front/partials/header')

@section('content')
<section class="banner_sec">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1>About Us</h1>
            </div>
        </div>
    </div>
</section>
<section class="playground_sec about_sec" style="background:url('front/assets/img/playground_back.png');">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-sm-12">
                <h2 class="">404</h2>
                
                 <a href="" class="gradient_btn icon_btn">Learn More<i class="fa-solid fa-arrow-right"></i></a> 
            </div>
            
        </div>
    </div>
</section>
@endsection