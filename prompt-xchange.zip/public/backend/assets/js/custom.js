jQuery('.dashboard_header .prof_box .down a').click(function() {
    jQuery('.dashboard_header .prof_box .down .xtra_links').toggle();
});
