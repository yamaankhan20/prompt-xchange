<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BackendController extends Controller
{
    //
    public function dashboard(){
        $data = ["title" =>"Dashboard | Prompt Xchange"];
        return view('backend.account-dashboard',$data);
    }

   public function testApi(Request $request)
{

     $request->validate([
        'file' => 'nullable|file|mimes:jpg,png,jpeg',
        'inpainting' => 'nullable|file|mimes:jpg,png,jpeg',
    ]);
    $model =  $request->model_name;
    $image_prompt = $request->file('image_prompt');
    $inpainting = $request->file('inpainting');
    $positive_prompt = $request->positive_prompt;
    $negative_prompt = $request->negative_prompt;
    $num_inference_steps = $request->steps;
    $guidance_scale  = $request->cdg_scale;
    $samples =  $request->samples;

    if (empty($image_prompt) && empty($inpainting)) {

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('https://modelslab.com/api/v3/text2img', [
            'key' => 'HlUWYMUSIX0oQHHdmOJCI4ECICejcJxbcZuwdr15cie9hEMTHxJubfeuRSnP',
            'prompt' => $positive_prompt,
            'negative_prompt' => $negative_prompt,
            'width' => '1024',
            'height' => '1024',
            'samples' => $samples,
            'num_inference_steps' => $num_inference_steps,
            'guidance_scale' => $guidance_scale,

        ]);
    } elseif (!empty($image_prompt)) {

        $imageName = time() . '.' . $image_prompt->getClientOriginalExtension();
        $imagePath = $image_prompt->storeAs('public/image_prompt_images', $imageName);
        $imageUrl = asset('storage/image_prompt_images/' . $imageName);


        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('https://modelslab.com/api/v3/img2img', [
            'key' => 'HlUWYMUSIX0oQHHdmOJCI4ECICejcJxbcZuwdr15cie9hEMTHxJubfeuRSnP',
            'prompt' => $positive_prompt,
            'negative_prompt' => $negative_prompt,
            'init_image' => $imageUrl,
            'width' => '1024',
            'height' => '1024',
            'samples' => $samples,
            'num_inference_steps' => $num_inference_steps,
            'guidance_scale' => $guidance_scale,
            'strength' => 0.7,

        ]);
    } elseif (!empty($inpainting)) {

        $inpainting_imageName = time() . '.' . $inpainting->getClientOriginalExtension();
        $inpaing_imagePath = $image_prompt->storeAs('public/inpaint_images', $inpainting_imageName);
        $inpaint_imageUrl = asset('storage/inpaing_images/' . $inpainting_imageName);

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('https://modelslab.com/api/v6/realtime/inpaint', [
            'key' => 'HlUWYMUSIX0oQHHdmOJCI4ECICejcJxbcZuwdr15cie9hEMTHxJubfeuRSnP',
            'prompt' => $positive_prompt,
            'negative_prompt' => $negative_prompt,
            'init_image' => "$inpaint_imageUrl",
            'mask_image' => "https://raw.githubusercontent.com/CompVis/stable-diffusion/main/data/inpainting_examples/overture-creations-5sI6fQgYIuo_mask.png" ,
            'width' => '1024',
            'height' => '1024',
            'samples' => $samples,
            'temp' => 'yes',
            'safety_checker'=>'no',
            'num_inference_steps' => $num_inference_steps,
            'guidance_scale' => $guidance_scale,
            'strength' => 0.7,
            'seed' =>null,
            'webhook'=> null,
            'track_id'=> null

        ]);
    }

    if ($response->successful()) {
        $result = $response->json();
        return response()->json($result);
    } else {
        $error = $response->body();
        return response()->json(['error' => $error], $response->status());
    }
}


}
